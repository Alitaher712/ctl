#include "../test.h"

#define P
#define T int
#include <deq.h>

#define T deq_int
#include <lst.h>

#define T deq_int
#include <pqu.h>

#define T deq_int
#include <que.h>

#define T deq_int
#include <set.h>

#define T deq_int
#include <stk.h>

#define T deq_int
#include <vec.h>

#define T deq_int
#include <ust.h>

#define P
#define T int
#include <lst.h>

#define T lst_int
#include <pqu.h>

#define T lst_int
#include <que.h>

#define T lst_int
#include <set.h>

#define T lst_int
#include <stk.h>

#define T lst_int
#include <vec.h>

#define T lst_int
#include <ust.h>

#define T lst_int
#include <deq.h>

#define P
#define T int
#include <pqu.h>

#define T pqu_int
#include <que.h>

#define T pqu_int
#include <set.h>

#define T pqu_int
#include <stk.h>

#define T pqu_int
#include <vec.h>

#define T pqu_int
#include <ust.h>

#define T pqu_int
#include <deq.h>

#define T pqu_int
#include <lst.h>

#define P
#define T int
#include <que.h>

#define T que_int
#include <set.h>

#define T que_int
#include <stk.h>

#define T que_int
#include <vec.h>

#define T que_int
#include <ust.h>

#define T que_int
#include <deq.h>

#define T que_int
#include <lst.h>

#define T que_int
#include <pqu.h>

#define P
#define T int
#include <set.h>

#define T set_int
#include <stk.h>

#define T set_int
#include <vec.h>

#define T set_int
#include <ust.h>

#define T set_int
#include <deq.h>

#define T set_int
#include <lst.h>

#define T set_int
#include <pqu.h>

#define T set_int
#include <que.h>

#define P
#define T int
#include <stk.h>

#define T stk_int
#include <vec.h>

#define T stk_int
#include <ust.h>

#define T stk_int
#include <deq.h>

#define T stk_int
#include <lst.h>

#define T stk_int
#include <pqu.h>

#define T stk_int
#include <que.h>

#define T stk_int
#include <set.h>

#define P
#define T int
#include <vec.h>

#define T vec_int
#include <ust.h>

#define T vec_int
#include <deq.h>

#define T vec_int
#include <lst.h>

#define T vec_int
#include <pqu.h>

#define T vec_int
#include <que.h>

#define T vec_int
#include <set.h>

#define T vec_int
#include <stk.h>

#define P
#define T int
#include <ust.h>

#define T ust_int
#include <deq.h>

#define T ust_int
#include <lst.h>

#define T ust_int
#include <pqu.h>

#define T ust_int
#include <que.h>

#define T ust_int
#include <set.h>

#define T ust_int
#include <stk.h>

#define T ust_int
#include <vec.h>

int
main(void)
{
    TEST_PASS(__FILE__);
}
